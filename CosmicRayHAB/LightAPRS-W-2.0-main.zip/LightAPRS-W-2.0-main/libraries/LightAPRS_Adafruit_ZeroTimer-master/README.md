# Adafruit_ZeroTimer [![Build Status](https://github.com/adafruit/Adafruit_ZeroTimer/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/Adafruit_ZeroTimer/actions)[![Documentation](https://github.com/adafruit/ci-arduino/blob/master/assets/doxygen_badge.svg)](http://adafruit.github.io/Adafruit_ZeroTimer/html/index.html)

simple wrappers for TC modules 3,4,5 on SAMD21 and SAMD51

## This code is not for public consumption!
we use this library internally for some things, and published it but it is not supported, or documented or guaranteed to work whatsoever!
